available_functions = '''

>>> Made with LOVE and HARDWORK...

	mod(vector=[2,1,2])
	showplane(n=[1, 1, 2])
	showline(a=[-1,0,2], b=[4,4,4], u=1)
	line(a=[1,2,-4], b=[2,3,6], two_points = False, sno='')
	plane(a=[2,5,-3], n=[-2,-3,5], p=[5,3,-3], dis=34, nd = False, three_points = False, sno='')
	comp_hcf(x=15, y=80)
	distbw2line(a1=[1,2,-4], b1=[2,3,6], a2=[3,3,-5], b2=[2,3,6])
	coplanof2line(a1=[-3, 1,5], b1=[-3,1,5], a2=[-1,2,5], b2=[-1,2,5])
	angbw2plane(n1=[2,1,-2], d1=5, n2=[2,1,-2], d2=7)
	distbwpointandplane(a=[2,5,-3], n=[6,-3,2], d=4)
	angbwlineandplane(a=[2,5,-3], b=[3,5,1], n=[6,-3,2], d=4)

....The moving power of mathematical invention is not 
reasoning but imagination. – A.DEMORGAN
'''

print('\n>>> Available functions are...\n', available_functions)
