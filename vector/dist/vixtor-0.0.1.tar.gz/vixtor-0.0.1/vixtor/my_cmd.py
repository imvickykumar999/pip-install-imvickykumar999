import os

class command:

    def cmd():
    
        print('\n\n>>>>====================== Welcome to Vicky\'s CMD ======================<<<<')
        print('\nWrite exit() to EXIT My_CMD\n')
        
        cmd = input('\nEnter command : ')
        os.system(cmd)

command.cmd()